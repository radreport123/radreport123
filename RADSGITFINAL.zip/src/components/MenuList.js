export const MenuList = [
  {
    title: "Incomplete Studies",
    url: "/CompleteStudies",
  },
  {
    title: "Complete Studies",
    url: "/features",
  },
  {
    title: "All Studies",
    url: "/pricing",
  },
  {
    title: "All Accounts",
    url: "/testimonials",
  },

];