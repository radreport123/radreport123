import React from 'react'

function UploadStudiesScreen() {
    return (
        <div className='dropbox-container'>
          
            <span>dsfsdfsdf</span>
            {/* <p>Email : .....</p>
            <P>Modality : .....</P>
            <p>Study Date : ....</p>
            <p>Gender : .....</p>
            <p>Date-of-birth : .....</p>
            <p>Description : .....</p> */}
 
        </div>
    )
}

export default UploadStudiesScreen
