import React from 'react'

function AllAccounts() {
    return (
        <div>
            AllAccounts
        </div>
    )
}

export default AllAccounts
