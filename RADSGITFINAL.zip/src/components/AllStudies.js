import React from 'react'

function AllStudies() {
    return (
        <div>
            <p>sdasdas</p>
        </div>
    )
}

export default AllStudies
